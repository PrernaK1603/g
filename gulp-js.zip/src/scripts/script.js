$(document).ready(function() {
  $(function() {
    $("h3[data-target]").attr("aria-expanded", false);
    $("h3[data-target=lifelock-panel]").attr("aria-expanded", true);
  });
  /* Script for Desktop Tabs */
  $(document).on("click", ".feature-tabs .tabs .tab", function() {
    $(".feature-tabs .tabs .tab").removeClass("active");
    $(this).addClass("active");
    $(".feature-tabs .tab-content").hide();
    currentTab = $(this).data("target");
    $(".feature-tabs .tab-content." + currentTab).show();
  });
  /* Script for mobile view accordion*/
  $(document).on("click", ".feature-tabs-accordion h3", function() {
    $(".feature-tabs-accordion h3").each(function() {
      var target = $(this).attr("data-target");
      $(this).attr("aria-expanded", false);
      $("." + target).hide();
    });
    var target = $(this).attr("data-target");

    $("." + target).show();
    $(this).attr("aria-expanded", true);
  });
});
