var gulp = require("gulp");
var spritesmith = require("gulp.spritesmith");
var imagemin = require("gulp-imagemin");
var fs = require("fs");
var json_img = JSON.parse(fs.readFileSync("./config/config.json"));

function minify_image(done) {
  files = [json_img.images.src];
  fs.exists(files, function(exists) {
    gulp
    .src(files)
    .pipe(imagemin())
    .pipe(gulp.dest(json_img.images.dest_mini_img));
    done();
  });
  
}


function image_sprite(done) {
  var spriteData = gulp.src(json_img.images.src).pipe(
    spritesmith({
      imgName: json_img.images.output_img,
      cssName: json_img.images.output_scss
    })
  );
  spriteData.img.pipe(gulp.dest(json_img.images.dest_img));
  spriteData.css.pipe(gulp.dest(json_img.images.dest_scss));
  done();
}

const imageTasks = gulp.series(minify_image,image_sprite);
exports.imageTasks = imageTasks;

//gulp.task("sprites", image_sprite);

//gulp.task("optimize", minify_image);
