var gulp = require("gulp");
var jsonMinify = require("gulp-jsonminify");
var fs = require("fs");
var json = JSON.parse(fs.readFileSync("./config/config.json"));

function json_minify(done) {
  files = [json.mini_json.json_src];
  fs.exists(files, function(exists) {
    gulp
    .src(files)
    .pipe(jsonMinify())
    .pipe(gulp.dest(json.mini_json.json_dest));
    done();
  });
  
}

const jsonTasks = gulp.series(json_minify);
exports.jsonTasks = jsonTasks;

//gulp.task("minify_json", json_minify);
