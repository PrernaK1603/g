var gulp = require("gulp");
var sass = require("gulp-sass");
var CleanCSS = require("gulp-clean-css");
var concat = require("gulp-concat-css");
var fs = require("fs");
var json = JSON.parse(fs.readFileSync("./config/config.json"));

/*var scss_css = function(done) {
  gulp
    //.src(json.scss_css.scss_src)
    .src("src/styles/*.scss")
    .pipe(sass())
    .pipe(gulp.dest("src/styles"));
    done();
};*/

var minify_css = function(done) {
  files = [json.scss_css.css_src];
  fs.exists(files, function(exists) {
    gulp
      .src(files)
      .pipe(CleanCSS())
      .pipe(gulp.dest(json.scss_css.dest_mini_css));
    done();
  });
};

var concate_css = function(done) {
  return gulp
    .src(json.scss_css.con_css_src)
    .pipe(concat(json.scss_css.con_css_file))
    .pipe(gulp.dest(json.scss_css.con_css_dest));
};
const cssTasks = gulp.series(minify_css, concate_css);
exports.cssTasks = cssTasks;
