var gulp = require("gulp");
var uglify = require("gulp-uglify");
var concats = require("gulp-concat");
var fs = require("fs");
var json_js = JSON.parse(fs.readFileSync("./config/config.json"));

function js_minify(done) {
  files = [json_js.mini_script.script_src];
  fs.exists(files, function(exists) {
    gulp
      .src(files)
      .pipe(uglify())
      .pipe(gulp.dest(json_js.mini_script.script_dest));
    done();
  });
}

function js_concate(done) {
  gulp
    .src(json_js.mini_script.con_script_src)
    .pipe(concats(json_js.mini_script.con_script_file))
    .pipe(gulp.dest(json_js.mini_script.con_script_dest));
  done();
}

//gulp.task("minify_js", js_minify);

//gulp.task("concate_js", js_concate);

const jsTasks = gulp.series(js_minify, js_concate);
exports.jsTasks = jsTasks;
